<?php


namespace Twilio\Exceptions;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

class ConfigurationException extends TwilioException {

}