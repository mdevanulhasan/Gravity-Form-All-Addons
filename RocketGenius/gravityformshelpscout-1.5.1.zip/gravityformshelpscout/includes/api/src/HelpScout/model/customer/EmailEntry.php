<?php
namespace HelpScout\model\customer;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

class EmailEntry extends CustomerEntry {
	
}