<?php
namespace HelpScout;

class ValidationException extends \Exception
{

}
