<?php
require_once '../../../wp-load.php';

if( !isset($_POST['formid']) or !isset($_POST['leadid']) or !isset($_POST['fieldid']) or !isset($_POST['idsuffix']) or !isset($_POST['val']) or !isset($_POST['orig']) or !isset($_POST['ext']) )
	return;
	
global $wpdb;

$formid 	= (int)$_POST['formid'];
$leadid 	= (int)$_POST['leadid'];
$fieldid 	= (int)$_POST['fieldid'];
$idsuffix 	= (int)str_replace( '_', '', $_POST['idsuffix'] );
$val 		= sanitize_file_name($_POST['val']);
$orig 		= filter_var( $_POST['orig'], FILTER_SANITIZE_STRING );
$ext 		= filter_var( $_POST['ext'], FILTER_SANITIZE_STRING );
$name		= $orig;
$long		= false;

$row = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}rg_lead_detail WHERE lead_id = $leadid AND form_id = $formid AND field_number = $fieldid");

if( empty($row) or empty($row->value) )
	return;

$rowid = $row->id;

if( class_exists("GFUser") or class_exists("GF_User_Registration") ){

	if( defined('GF_USER_REGISTRATION_VERSION') and version_compare( GF_USER_REGISTRATION_VERSION, '3', '>=' ) ){
		
		$gfurclass	= 'GF_User_Registration';
		$gfurd		= 'new';
	
	}else{
		
		$gfurclass	= 'GFUserData';
		$gfurd		= 'old';
		
	}
			
	if($gfurd == 'old'){	

		require_once(GFUser::get_base_path()."/data.php");

		$config	= $gfurclass::get_update_feed($formid);
		$user	= $gfurclass::get_user_by_entry_id($leadid);
	
	}else{
		
		$config	= gf_user_registration()->get_update_feed($formid);
		$user	= gf_user_registration()->get_user_by_entry_id($leadid);							
		
	}
							
	$userid = $user ? $user->ID : 0;
	
}

if(strlen($row->value) >= (GFORMS_MAX_FIELD_LENGTH - 10)){
					
	$form 	= RGFormsModel::get_form_meta($formid);
	$lead	= GFRcwdCommon::get_lead($leadid);
	$value 	= GFFormsModel::get_field_value_long( $lead, $idsuffix, $form );
	$long	= true;
		
}else
	$value = $row->value;
	
$value			= unserialize($value);
$currfile		= $value[$idsuffix]['file'];
$upload_info 	= GFRcwdCommon::upload_info( $formid, $fieldid, $leadid, $userid );
$final			= $val.'.'.$ext;

if(file_exists($upload_info['path'].$currfile)){
	
	if($userid > 0){
		
		$filefields = $value;
		$form 		= RGFormsModel::get_form_meta($formid);
		$lead		= GFRcwdCommon::get_lead($leadid);
		$fields		= $form['fields'];
		$names		= array();

		foreach($fields as $field){
			
			$changed = false;
			
			if($field['type'] == 'rcwdupload'){
				
				if($field['id'] != $fieldid){
					
					$filefields	= $lead[$field['id']];
					$filefields	= maybe_unserialize($filefields);
					
					if(!empty($filefields))
						foreach($filefields as $key => $filefield)
							$names[] = $filefield['file'];
						
				}
				
			}
			
		}
				
		if(count($names) > 0 and in_array( $val.'.'.$ext, $names ) ){
			
			$count = 1;
			
			while (in_array( $val.'_'.$count.'.'.$ext, $names ))
				$count++;		
		
			$final = $val.'_'.$count.'.'.$ext;
			
		}

	}
						
	$value[$idsuffix]['file'] 	= $final;
	$value 						= serialize($value);

	rename( $upload_info['path'].$currfile, $upload_info['path'].$final );
	
	if($long){

		if($wpdb->update( $wpdb->prefix.'rg_lead_detail_long', array('value' => $value), array( 'lead_detail_id' => $rowid ), array( '%s' ), array( '%d' ) ))
			echo json_encode(array('name' => $final));

	}else
		if($wpdb->update( $wpdb->prefix.'rg_lead_detail', array('value' => $value), array( 'lead_id' => $leadid, 'form_id' => $formid, 'field_number' => $fieldid ), array('%s'), array('%d', '%d', '%d') ))
			echo json_encode(array('name' => $final));	
	
}else
	echo json_encode(array('error' => true));	
?>