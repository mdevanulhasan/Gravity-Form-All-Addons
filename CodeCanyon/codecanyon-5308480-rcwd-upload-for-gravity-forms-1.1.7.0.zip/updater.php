<?php
class GFRcwdUpdater{
	
	public function init(){
		
		add_filter( 'upgrader_pre_download', array( $this, 'upgrader_pre_download'), 10, 4 );
		add_action( 'upgrader_process_complete', array( $this, 'removeTemporaryDir' ) );

	}
	
	function upgrader_pre_download( $reply, $package, $updater ){

		global $wp_filesystem;

		$error = __( 'Error! Envato username, api key and your purchase code are required for downloading updates from Envato marketplace.', 'gforms-rcwdupload' );

		if(empty($package))
			return new WP_Error( 'no_credentials', $error );
						
		if( ( isset($updater->skin->plugin) and $updater->skin->plugin === GFORMS_RCWDUPLOAD_NAME ) or ( isset($updater->skin->plugin_info) and $updater->skin->plugin_info['Name'] === GFORMS_RCWDUPLOAD_TITLE ) ){
			
			$updater->strings['download_envato'] = __( 'Downloading package from envato market...', 'gforms-rcwdupload' );

			$updater->skin->feedback('download_envato');
			
			$package_filename 	= 'gravityforms-rcwdupload.zip';
			$res 				= $updater->fs_connect(array(WP_CONTENT_DIR));
			
			if(!$res)
				return new WP_Error( 'no_credentials', __( "Error! Can't connect to filesystem", 'gforms-rcwdupload' ) );

			$check			= get_option('gforms_rcwdupload_verifypurchase');
			$username		= isset($check['username']) 		? trim($check['username'] )		: '';
			$api_key		= isset($check['api_key'])			? trim($check['api_key'])		: '';
			$purchase_code	= isset($check['purchase_code'])	? trim($check['purchase_code'])	: false;
			
			if( empty($username) or empty($api_key) or empty($purchase_code) )
				return new WP_Error( 'no_credentials', $error );

			if(empty($package))
				return new WP_Error( 'no_credentials', __( 'Error! Envato API error' . ( isset( $result['error'] ) ? ': ' . $result['error'] : '.' ), 'gforms-rcwdupload' ) );
			$download_file = download_url($package);

			if(is_wp_error($download_file))
				return $download_file;

			$plugin_directory_name = 'gravityforms-rcwdupload';
	
			if(basename( $download_file, '.zip' ) !== $plugin_directory_name){
				
				$new_archive_name = dirname($download_file).'/'.$plugin_directory_name.'.zip';

				rename( $download_file, $new_archive_name );
				
				$download_file = $new_archive_name;
				
				return $download_file;
				
			}

			return new WP_Error( 'no_credentials', __( 'Error on unzipping package', 'gforms-rcwdupload' ) );
			
		}
		
		return $reply;
				
	}

	public function removeTemporaryDir(){
		
		global $wp_filesystem;
		
		if(is_dir($wp_filesystem->wp_content_dir().'uploads/gformsrcwdupload_envato_package'))
			$wp_filesystem->delete( $wp_filesystem->wp_content_dir().'uploads/gformsrcwdupload_envato_package', true );

	}
			
}
?>