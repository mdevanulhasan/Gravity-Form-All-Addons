<?php
if(class_exists('GF_Field')){
	
	class GF_Field_Rcwdupload extends GF_Field {
	
		public $type = 'rcwdupload';
		
		function __construct( $data = array()){
	
			if(empty($data))
				return;
	
			foreach( $data as $key => $value )
				$this->{$key} = $value;
			
			// GFORMS USER REGISTRATION PLUGIN _______________________________________________________________________
			
				if( defined('GF_USER_REGISTRATION_VERSION') and version_compare( GF_USER_REGISTRATION_VERSION, '3', '>=' ) ){
					
					$this->gfurclass	= 'GF_User_Registration';
					$this->gfurd		= 'new';
				
				}else{
					
					$this->gfurclass	= 'GFUserData';
					$this->gfurd		= 'old';
					
				}		
	
			// _______________________________________________________________________________________________________
			
			$this->rnm_search = array( '[form_id]', '[field_id]', '[lead_id]', '[fieldlabel]', '[field:ID]' );
			
		}
	
		public function get_form_editor_button(){
			
			return array(
			
				'group' => 'standard_fields',
				'text'  => __( 'RCWD Uploader', 'gforms-rcwdupload' )
				
			);
			
		}
			
		public function get_form_editor_field_title(){
			
			return esc_attr__( 'RCWD Uploader', 'gforms-rcwdupload' );
			
		}
	
		public function get_form_editor_field_settings(){
			
			return array(
			
				'conditional_logic_field_setting',
				'prepopulate_field_setting',
				'error_message_setting',
				'label_setting',
				'label_placement_setting',
				'admin_label_setting',
				'size_setting',
				'input_mask_setting',
				'maxlen_setting',
				'password_field_setting',
				'rules_setting',
				'visibility_setting',
				'duplicate_setting',
				'default_value_setting',
				'placeholder_setting',
				'description_setting',
				'css_class_setting',
				
			);
			
		}
		
		public function get_field_input( $form, $value = '', $lead = null ) {
	
			$form_id         	= absint( $form['id'] );
			$is_entry_detail 	= $this->is_entry_detail();
			$is_form_editor  	= $this->is_form_editor();
			$field				= $this;	
			$fid          		= (int)$this->id;
			$input    			= $is_entry_detail || $is_form_editor || $form_id == 0 ? "input_$fid" : 'input_'.$form_id."_$fid";
			
			if(is_array($lead) and count($lead) > 0)	
				$lead_id = $lead['id'];
			else
				$lead_id = 0;
	
			return gforms_rcwdupload_plugin::gform_field_input( $input, $field, $value, $lead_id, $form_id );
	
		}
		
		public function get_value_save_entry( $value, $form, $input_name, $lead_id, $lead ) {
			
			$field = $this;	

		if( $field->enableCopyValuesOption and rgpost( 'input_'.$field->id.'_copy_values_activated' ) ){
			
			$source_field_id   = $field->copyValuesOptionField;
			$source_input_name = str_replace( 'input_' . $field->id, 'input_'.$source_field_id, $input_name );
			$value             = rgpost($source_input_name);
			
		}else
			$value = rgpost( $input_name, false );
		
			if(empty($lead))
				$lead = GFRcwdCommon::get_lead($lead_id);

			if( !empty($lead) and (is_array($lead)) and count($lead) > 0 )
				return gforms_rcwdupload_plugin::save_field_value( $value, $lead, $field, $form );
			
		}
		
		public function maybe_override_field_value( $field_value, $form, $entry, $field_id ){
			
			return $field_value;
			
		}
		
		
			
	}
	
	GF_Fields::register(new GF_Field_Rcwdupload());

}
?>