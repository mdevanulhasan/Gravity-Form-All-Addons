Plugin Name: Double opt in for Gravity Forms
Plugin URI: 
Description: Only get e-mails from senders who verified their e-mail addresses via double-opt in.
Version: 1.0
Author: Albert Brueckmann
Author URI: https://albertbrueckmann.de/double-opt-in-for-gravity-forms/


How it works: 

1) Add plugin in plugin directory
2) Activate plugin
3) Add form in gravity forms
4  In admin notification email select "send after verification" events
5) Create new notification for user (select event form is submitted  Or Send verification email to user )
6) add {confirm_url} in user notification email
