<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://meydjer.com
 * @since      1.0.0
 *
 * @package    Lastform
 * @subpackage Lastform/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Lastform
 * @subpackage Lastform/public
 * @author     Meydjer Windmüller <meydjer@gmail.com>
 */
class Lastform_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $_slug    The ID of this plugin.
	 */
	private $_slug;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $_version    The current version of this plugin.
	 */
	private $_version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $_slug       The name of the plugin.
	 * @param      string    $_version    The version of this plugin.
	 */
	public function __construct( $_slug, $_version ) {
		$this->_slug = $_slug;
		$this->_version = $_version;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function register_styles() {
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_register_style( $this->_slug, plugin_dir_url( __FILE__ ) . "css/lastform-public{$min}.css", array(), $this->_version, 'all' );

		/**
		 * Form Google Fonts
		 */

		// Get form ID.
		$form_id = absint( get_query_var('lastform') );
		if ($form_id) {
			// Get form object.
			$form = GFFormsModel::get_form_meta( $form_id );
			// Get form options
			$options = lastform_addon()->get_form_settings( $form );

			if (!empty($options['google-font-code'])) {
				$google_font_code = str_replace('+', ' ', $options['google-font-code']);

				$font_url = add_query_arg( 'family', urlencode( $google_font_code ), "//fonts.googleapis.com/css" );

				wp_register_style( 'google-fonts', $font_url, array(), null );
			}

		}
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts($form) {

		/**
		 * Exit if it's not called from the Lastform template
		 */
		if (!get_query_var('lastform')) {
			return false;
		}

		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		/**
		 * jquery-waypoints
		 */
		wp_enqueue_script( 'jquery-waypoints', Lastform::plugin_url() . "includes/vendor/waypoints/jquery.waypoints{$min}.js", array( 'jquery' ), '4.0.1', false );

		if (!$min) {
			wp_enqueue_script( 'jquery-waypoints-debug', Lastform::plugin_url() . "includes/vendor/waypoints/waypoints.debug.js", array( 'jquery', 'jquery-waypoints' ), '4.0.1', false );
		}

		/**
		 * autogrow.js
		 */
		wp_enqueue_script( 'autogrow', Lastform::plugin_url() . "includes/vendor/autogrow/autogrow{$min}.js", array( 'jquery' ), '1.0.3', false );

		/**
		 * object-watch.js
		 */
		wp_enqueue_script( 'object-watch.js', Lastform::plugin_url() . 'includes/vendor/object-watch.js/object-watch.js' );

		/**
		 * select2.js
		 */
		wp_enqueue_script( 'select2', Lastform::plugin_url() . "includes/vendor/select2/dist/js/select2{$min}.js", array( 'jquery' ), '4.0.3' );

		$select2_lang        = str_replace('_', '-', get_locale());
		$select2_lang_exists = false;

		if ($this->select2_i18n_file_exists($select2_lang)) {
			$select2_lang_exists = true;
		} else {
			$select2_lang = explode('-', $select2_lang);
			$select2_lang = $select2_lang[0];
			if ($this->select2_i18n_file_exists($select2_lang)) {
				$select2_lang_exists = true;
			}
		}

		if ($select2_lang_exists) {
			wp_enqueue_script( 'select2-i18n', Lastform::plugin_url() . "includes/vendor/select2/dist/js/i18n/{$select2_lang}.js", array( 'jquery', 'select2' ), '4.0.3' );
		}

		/**
		 * Lastform js
		 */

		wp_register_script( $this->_slug, plugin_dir_url( __FILE__ ) . "js/lastform-public{$min}.js", array( 'jquery', 'jquery-waypoints', 'autogrow', 'object-watch.js', 'select2', 'gform_gravityforms' ), $this->_version, false );

		$translation_array = array(
			'multichoice_tip'        => esc_attr__( 'Choose as many as you like and', 'lastform' ) . ' <strong>' . esc_attr__('press ENTER', 'lastform') . '</strong>',
			'multichoice_tip_mobile' => esc_attr__( 'Choose as many as you like', 'lastform' ),
			'hint_key'               => esc_attr__( 'Key', 'lastform' ),
			'textarea_tip'           => esc_attr__( 'To add a paragraph, press ', 'lastform' ) . '<strong>' . esc_attr__('SHIFT + ENTER', 'lastform') . '</strong>',
			'upload_button'          => esc_attr__( 'Upload', 'lastform' ),
			'press_enter'            => esc_attr__( 'press', 'lastform' ) . ' <strong>' . esc_attr__( 'ENTER', 'lastform' ) . '</strong>',
			'progress_percentage'    => esc_attr__('position: $1', 'lastform'),
			'progress_proportional'  => esc_attr__('viewing $1 of $2', 'lastform'),
		);

		wp_localize_script( $this->_slug, 'lastformLocalize', $translation_array );
		wp_enqueue_script( $this->_slug );

	}


	/**
	 * Filter GForm assets
	 * @since     1.0.0
	 */
	public function filter_gform_assets() {
		/**
		 * Exit if it's not called from the Lastform template
		 */
		if (!get_query_var('lastform')) {
			return false;
		}

		wp_dequeue_script('chosen');
		wp_dequeue_script('gform_chosen');
		wp_dequeue_style('gforms_datepicker_css');
		wp_dequeue_style('gforms_formsmain_css');
		wp_dequeue_style('gforms_ready_class_css');
		wp_dequeue_style('gforms_browsers_css');
		wp_dequeue_style('gforms_reset_css');
	}


	/**
	 * Compatibility issues
	 *
	 * @since    1.0.0
	 */
	public function compatibility() {

		/**
		 * Exit if it's not called from the Lastform template
		 */
		if (!get_query_var('lastform')) {
			return false;
		}

		// Needed to use is_plugin_active()
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

		/**
		 * Social Gallery
		 */
		if (is_plugin_active( 'SocialGallery/SocialGallery.php')) {
			wp_dequeue_script( 'sgp-gestures' );
			wp_dequeue_script( 'socialGalleryPluginEpic' );
			wp_dequeue_style( 'socialGalleryPluginCSS' );
		}

	}


	/**
	 * Check if the correspondent select2 i18n file exists
	 * @since     1.0.0
	 * @param     string    $lang    language code
	 * @return    boolean
	 */
	public function select2_i18n_file_exists($lang) {
		return file_exists(plugin_dir_path( __FILE__ ).'../includes/vendor/select2/dist/js/i18n/'.$lang.'.js');
	}


	/**
	 * Processes pages that are not loaded directly within WordPress
	 *
	 * @access public
	 * @static
	 * @see GFCommon
	 */
	public function process_form_page() {
		$lastform_query = get_query_var('lastform');

		if ( empty($lastform_query) ) {
			return;
		} else {
			require_once( plugin_dir_path( __FILE__ ) . 'partials/lastform-public-display.php' );
			exit();
		}
	}


	/**
	 * Create Lastform route
	 * @since     1.0.0
	 */
	public function add_route(){
		$setting = lastform_addon()->get_plugin_setting('form_url_slug');
		$slug = (!empty($setting)) ? $setting : 'lastform';
	    add_rewrite_rule(
	        $slug . '/([0-9]+)/?$',
	        'index.php?lastform=$matches[1]',
	        'top' );
	}


	/**
	 * Add 'lastform' param to the query
	 * @since     1.0.0
	 * @param     array    $query_vars    All current query vars
	 * @return    array                   New query cars
	 */
	public function query_vars( $query_vars ){
	    $query_vars[] = 'lastform';
	    return $query_vars;
	}

	/**
	 * Print form inline styles
	 * @since     1.0.0
	 * @param     array    $form     GF form Array
	 * @echo      string             inline CSS code
	 */
	public static function print_form_inline_style($form) {
		$options = lastform_addon()->get_form_settings( $form );

		$css  = '';

		/**
		 * Default options
		 */
		$bg_color                 = (!empty($options['bg-color'])) ? $options['bg-color'] : '#ffffff';
		$bg_color_rgb             = Lastform_Color::hex2rgb($bg_color);
		$font_family              = (!empty($options['font-family-name'])) ? $options['font-family-name'] : '';
		$question_color           = (!empty($options['question-color'])) ? $options['question-color'] : '#3D3D3D';
		$answer_color             = (!empty($options['answer-color'])) ? $options['answer-color'] : '#41B3FF';
		$button_color             = (!empty($options['button-color'])) ? $options['button-color'] : '#41B3FF';
		$bg_image_url             = (!empty($options['bg-image-url'])) ? $options['bg-image-url'] : null;
		$bg_image_scaling         = (!empty($options['bg-image-scaling'])) ? $options['bg-image-scaling'] : 'fullscreen';
		$bg_luminosity            = (!empty($options['bg-luminosity'])) ? $options['bg-luminosity'] : 'darker';
		$bg_luminosity_level      = (!empty($options['bg-luminosity-level'])) ? $options['bg-luminosity-level'] : 0;
		$unfocused_fields_opacity = (!empty($options['uncofused-fields-transparency-level']) || (isset($options['uncofused-fields-transparency-level']) && $options['uncofused-fields-transparency-level'] === '0')) ? ((100 - $options['uncofused-fields-transparency-level']) / 100) : 0.2;

		/**
		 * Conditional BG color styles
		 */
		$darken_factor                 = Lastform_Color::get_light_or_dark( $bg_color, 30, 70 );
		$input_border_color            = Lastform_Color::light_or_dark( $bg_color, 'rgba(0,0,0,0.075)', 'rgba(255,255,255,0.075)' );
		$button_text_color             = Lastform_Color::light_or_dark( $button_color, 'rgba(0,0,0,.9)', '#fff' );
		$button_border_color           = Lastform_Color::hex_darker( $button_color, $darken_factor );
		$button_basic_border_color     = Lastform_Color::get_light_or_dark( $bg_color, 'rgba(0, 0, 0, .15)', 'rgba(0, 0, 0, .3)' );
		$button_basic_bg_color         = "rgba({$bg_color_rgb[0]},{$bg_color_rgb[1]},{$bg_color_rgb[2]},.7)";
		$progress_bar_bg_color         = Lastform_Color::light_or_dark( $bg_color, 'rgba(0,0,0,.1)', 'rgba(255,255,255,.05)' );
		$checked_text_color            = Lastform_Color::light_or_dark( $answer_color, 'rgba(0,0,0,.9)', '#fff' );
		$checked_bg_color              = $answer_color;
		$checked_border_color          = Lastform_Color::hex_darker( $answer_color, $darken_factor );
		$shortcut_border_color         = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, .1)', 'rgba(255, 255, 255, .2)' );
		$shortcut_text_color           = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, .4)', 'rgba(255, 255, 255, .6)' );
		$shortcut_hover_bg_color       = $answer_color;
		$shortcut_hover_border_color   = Lastform_Color::hex_darker( $answer_color, $darken_factor );
		$shortcut_hover_text_color     = Lastform_Color::light_or_dark( $answer_color, 'rgba(0,0,0,.9)', '#fff' );
		$checked_shortcut_border_color = $checked_border_color;
		$checked_shortcut_text_color   = Lastform_Color::hex_darker( $checked_border_color, 10 );
		$dropdown_text_color           = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, .9)', 'rgba(255, 255, 255, .9)' );
		$price_text_color              = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, .4)', 'rgba(255, 255, 255, .3)' );
		$checked_price_text_color      = Lastform_Color::light_or_dark( $answer_color, 'rgba(0, 0, 0, .6)', 'rgba(255, 255, 255, .5)' );
		$field_tip_text_color          = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, 0.55)', 'rgba(255, 255, 255, .5)' );
		$field_tip_icon_color          = Lastform_Color::light_or_dark( $bg_color, 'rgba(0, 0, 0, 0.5)', 'rgba(255, 255, 255, .45)' );

		/**
		 * Base CSS
		 */
		$css .= "
			body,
			.lf-continue-help {
				background-color:{$bg_color};
				color:{$question_color};
				font-family:'{$font_family}', Helvetica Neue, Helvetica, Arial, sans-serif;
			}
			.gform_wrapper .gform_footer {
				background-color:{$bg_color};
			}
			.gform_wrapper .ginput_container input:not([type='radio']):not([type='checkbox']):not([type='submit']):not([type='image']):not([type='file']),
			.gform_wrapper .ginput_container textarea,
			.select2-container--default .select2-search--dropdown .select2-search__field {
				border-color:{$input_border_color};
				color:{$answer_color};
			}
			.gform_wrapper span.ginput_total,
			.gform_wrapper span.ginput_product_price,
			.lf-keyboard-icon,
			.ui-datepicker .ui-datepicker-calendar tbody td a {
				color:{$answer_color};
			}
			.gform_wrapper .ginput_container input:not([type='radio']):not([type='checkbox']):not([type='submit']):not([type='image']):not([type='file']):focus,
			.gform_wrapper .ginput_container textarea:focus,
			.select2-container--default .select2-search--dropdown .select2-search__field:focus,
			.select2-container--default.select2-container--focus .select2-selection--multiple {
				border-color:{$answer_color};
			}
			.gform_wrapper .gfield_radio li,
			.gform_wrapper .gfield_checkbox li,
			.select2-container--default .select2-selection--single .select2-selection__rendered,
			.select2-container--default .select2-selection--single .select2-selection__arrow b:before,
			select {
				color:{$answer_color};
			}
			.gform_wrapper ul.gfield_radio li,
			.gform_wrapper ul.gfield_checkbox li,
			.select2-container--default .select2-selection--single,
			.select2-dropdown,
			.lf-progress-box,
			select {
				border-color:{$button_basic_border_color};
				background-color:{$button_basic_bg_color};
			}
			.ui-datepicker {
				border-color:{$button_basic_border_color};
				background-color:{$bg_color};
			}
			.gform_wrapper ul.gfield_radio li.lf-checked,
			.gform_wrapper ul.gfield_checkbox li.lf-checked,
			select:focus,
			.gform_wrapper .ginput_container_fileupload .upload-button {
				background-color:{$checked_bg_color};
				border-color:{$checked_border_color};
				color:{$checked_text_color};
			}
			.gform_wrapper .gform_footer input[type=submit],
			.gform_wrapper .gform_footer input.button,
			.gform_wrapper .gform_page_footer input[type=submit],
			.gform_wrapper .gform_page_footer input.button,
			.lf-continue-help a,
			.lf-welcome-start-button,
			.lf-nav-arrow-up,
			.lf-nav-arrow-down {
				background-color:{$button_color};
				color:{$button_text_color};
				border-color:{$button_border_color};
			}
			.lf-progress-bar {
				background-color:{$progress_bar_bg_color};
			}
			.lf-progress-bar-fill {
				background-color:{$button_color};
			}
			.lf-preloader,
			.lf-preloader-animation:after {
				background-color:{$bg_color};
			}
			.lf-preloader-animation:before {
				background-image: -moz-radial-gradient(center, ellipse, rgba(65, 179, 255, 0) 17px, {$bg_color} 18px);
				background-image: -webkit-radial-gradient(center, ellipse, rgba(65, 179, 255, 0) 17px, {$bg_color} 18px);
				background-image: radial-gradient(ellipse at center, rgba(65, 179, 255, 0) 17px, {$bg_color} 18px);
				-moz-box-shadow: 0 0 0 56px {$bg_color};
				-webkit-box-shadow: 0 0 0 56px {$bg_color};
				box-shadow: 0 0 0 56px {$bg_color};
			}
			.lf-preloader-animation {
				background-color:{$button_color};
			}
			.lf-shortcut-hint {
				color:{$shortcut_text_color};
				border-color:{$shortcut_border_color};
			}
			.lf-checked .lf-shortcut-hint {
				color:{$checked_shortcut_text_color};
				border-color:{$checked_shortcut_border_color};
			}
			label:hover .lf-shortcut-hint,
			.lf-shortcut-hint h {
				color:{$shortcut_hover_text_color};
				border-color:{$shortcut_hover_border_color};
				background-color:{$shortcut_hover_bg_color};
			}
			.select2-container--default .select2-results__option {
				color:{$dropdown_text_color};
			}
			.select2-container--default .select2-results__option--highlighted[aria-selected],
			.select2-container--default .select2-selection--multiple .select2-selection__choice,
			.select2-container--default .select2-selection--multiple .select2-selection__choice__remove:before,
			.ui-datepicker .ui-datepicker-calendar tbody td a:hover,
			.ui-datepicker .ui-datepicker-calendar tbody td.ui-datepicker-current-day a {
				background-color:{$answer_color};
				color:{$bg_color};
			}
			.gform_wrapper .ginput_price {
				color:{$price_text_color};
			}
			.gform_wrapper .lf-checked .ginput_price {
				color:{$checked_price_text_color};
			}
			.lf-field-tip {
				color:{$field_tip_text_color};
			}
			.lf-field-tip i {
				color:{$field_tip_icon_color};
			}
			.gform_fields .gfield {
				opacity: {$unfocused_fields_opacity};
			}
		";

		/**
		 * Background Image CSS
		 */

		if ( ! empty($bg_image_url) ) {
			/**
			 * Image
			 */
			$css .= "
				.lf-bg {
					background-image:url({$options['bg-image-url']});
				}
			";

			/**
			 * Lighter or Darker
			 */
			if ($bg_luminosity_level && $bg_luminosity == 'lighter') {
				$css .= "
					.lf-bg:after {
						background-color:#fff;
					}
				";
			} else if ($bg_luminosity_level) {
				$css .= "
					.lf-bg:after {
						background-color:#000;
					}
				";
			}

			/**
			 * Luminosity level
			 */
			if ($bg_luminosity_level) {
				$bg_luminosity_level = $bg_luminosity_level / 100;
				$css .= "
					.lf-bg:after {
						opacity:{$bg_luminosity_level};
					}
				";
			}

			/**
			 * Image scaling
			 */
			switch ($bg_image_scaling) {
				case 'repeat':
					$css .= "
						.lf-bg {
							background-repeat: repeat;
						}
					";
					break;
				case 'no-repeat':
					$css .= "
						.lf-bg {
							background-repeat: no-repeat;
						}
					";
					break;
				// Fullscreen
				default:
					$css .= "
						.lf-bg {
							background-position: center;
							-moz-background-size: cover;
							-o-background-size: cover;
							-webkit-background-size: cover;
							background-size: cover;
						}
					";
					break;
			}
		}

		$css = apply_filters('lastform_public_get_form_inline_style', $css, $form);

		echo '<style>' . trim(preg_replace('/\s+/', ' ', $css)) . '</style>';
	}

}
