
var gpcpImporter;

( function( $ ) {

	console.log( 'Alive.' );

} )( jQuery );
