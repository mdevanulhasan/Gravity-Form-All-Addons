# Gravity Perks Better User Activation

Improve the User Activation feature for Gravity Forms.
