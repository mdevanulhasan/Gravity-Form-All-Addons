<h2>Your account is now active!</h2>

<strong>Username:</strong> {gpbua:username}<br>
<strong>Password:</strong> {gpbua:password}<br>
<br>
Your account is now activated. {gpbua:login} or go back to {gpbua:home}.