<h2>An error occurred during the activation</h2>

Activation was not successful due to the following error: {gpbua:error_message}