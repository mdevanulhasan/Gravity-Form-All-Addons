window.GPPA = new GPPopulateAnything();

function GPPopulateAnything() {

	var $ = window.jQuery;
	var self = this;

	this.init = function () {

		for (i in window.fieldSettings) {
			window.fieldSettings[i] += ', #gppa';
			window.fieldSettings[i] += ', #gppa-choices';
			window.fieldSettings[i] += ', #gppa-values';
		}

		$(document).bind('gform_load_field_settings', self.onLoadFieldSettings);

		$('.custom_inputs_setting, .custom_inputs_sub_setting, .sub_labels_setting')
			.on('click keypress', '.input_active_icon', function () {
				self.vm.$set(self.vm.$data.field, 'inputs', Object.assign({}, window.field.inputs));
			});

		this.initSelectWithCustomComponent();
		this.initFilterComponent();
		this.initResultsPreviewComponent();
		this.initGPPAPopulateDynamicallyComponent();
		this.initVueVM();

	};

	this.onLoadFieldSettings = function (event, field, form) {
		self.vm.$data.field = Object.assign({}, field);
	};

	this.initSelectWithCustomComponent = function () {

		Vue.component('gppa-select-with-custom', {
			template: '#gppa-select-with-custom',
			data: function () {
				return {
					i18nStrings: window.GPPA_ADMIN.strings,
					hasMergeTagSelector: false,
				}
			},
			mounted: function () {
				var vm = this;

				this.mergeTagsObj = new gfMergeTagsObj( window.form, jQuery(this.$refs.customInput) );
				this.mergeTagsObj.getMergeTags = this.getMergeTags;
				this.mergeTagsObj.getTargetElement = function () {
					return jQuery(vm.$refs.customInput);
				};

				/* GF Merge Tag selector doesn't trigger change by default so we need to shim that in. */
				jQuery(this.$refs.customInput).on('propertychange', function () {
					vm.$refs.customInput.dispatchEvent(new Event('input'));
				});

				this.hasMergeTagSelector = true;
			},
			beforeDestroy: function () {
				this.mergeTagsObj.destroy();
			},
			watch: {
				operator: function () {
					if (this.forceCustomInput && this.value.indexOf('gf_custom') !== 0) {
						this.$emit('change', 'gf_custom:' + this.value);
					}
				}
			},
			methods: {
				getMergeTags: function (fields, elementId, hideAllFields, excludeFieldTypes, isPrepop, option) {

					var vm = this;
					var mergeTags = {
						gppaProperties: {
							label: 'Properties',
							tags: []
						}
					};

					$.each(this.objectTypeInstance.groups, function (groupId, group) {
						mergeTags[groupId] = {
							label: group.label,
							tags: []
						};
					});

					$.each(this.flattenedProperties, function (index, property) {
						mergeTags[property.group || 'gppaProperties'].tags.push({
							tag: '{' + vm.objectTypeInstance.id + ':' + property.value + '}',
							label: property.label
						});
					});

					return gform.applyFilters('gppa_template_merge_tags', mergeTags, elementId, hideAllFields, excludeFieldTypes, isPrepop, option, this );

				},
				reset: function () {
					this.$emit('change', '');
				},
			},
			model: {
				prop: 'value',
				event: 'change'
			},
			computed: {
				selectValueProxy: {
					get: function () {
						return this.value;
					},
					set: function (newValue) {
						this.$emit('change', newValue);
					}
				},
				inputValueProxy: {
					get: function () {
						return this.value && this.value.toString().replace(/^gf_custom:?/, '');
					},
					set: function (newValue) {
						this.$emit('change', 'gf_custom:' + newValue);
					}
				},
				showCustomInput: function () {
					if (this.forceCustomInput) {
						return true;
					}

					return this.value && this.value.toString().indexOf('gf_custom') === 0;
				},
				forceCustomInput: function () {
					return ['like'].indexOf(this.operator) !== -1;
				}
			},
			props: {
				value: {
					type: [Number, String],
					default: function () {
						return '';
					}
				},
				additionalClass: String,
				operator: String,
				loading: {
					type: Boolean,
					default: function () {
						return false;
					}
				},
				objectTypeInstance: Object,
				flattenedProperties: Object,
			}
		});

	};

	this.initFilterComponent = function () {

		Vue.component('gppa-filter', {
			template: '#gppa-filter',
			props: [
				'filter',
				'field',
				'properties',
				'flattenedProperties',
				'propertyValues',
				'ungroupedProperties',
				'groupedProperties',
				'objectTypeInstance',
				'getPropertyValues',
			],
			created: function () {
				if (this.filter.property) {
					return this.getPropertyValues(this.filter.property);
				}

				this.filter.property = Object.values(this.flattenedProperties)[0].value;
			},
			data: function () {
				return {
					i18nStrings: window.GPPA_ADMIN.strings,
					defaultOperator: 'is',
				}
			},
			watch: {
				'filter.property': function (val, oldVal) {
					this.getPropertyValues(val);

					this.filter.value = '';
					this.filter.operator = this.defaultOperator;
				}
			},
			methods: {
				truncateStringMiddle: gppaTruncateStringMiddle,
			},
			computed: {
				specialValues: function () {

					return [
						{
							label: 'Current User ID',
							value: 'special_value:current_user:ID',
						},
						{
							label: 'Current Post ID',
							value: 'special_value:current_post:ID',
						}
					]

				},
				formFieldValues: function () {

					var formFieldValues = [];

					for (var i = 0; i < form.fields.length; i++) {

						var field = form.fields[i];

						if (IsConditionalLogicField(field)) {

							if (field.inputs && $.inArray(GetInputType(field), ['checkbox', 'email']) == -1) {
								for (var j = 0; j < field.inputs.length; j++) {
									var input = field.inputs[j];
									if (!input.isHidden) {
										formFieldValues.push({
											label: GetLabel(field, input.id),
											value: 'gf_field:' + input.id,
										});
									}
								}
							} else {
								formFieldValues.push({
									label: GetLabel(field),
									value: 'gf_field:' + field.id,
								});
							}

						}

					}

					return formFieldValues;

				},
				operators: function () {

					/* Labels for operators are pulled from i18nStrings in the Vue bindings */
					if (this.filter.property in this.flattenedProperties) {
						var property = this.flattenedProperties[this.filter.property];

						if ('operators' in property) {
							return property.operators;
						}

						if ('group' in property) {
							var group = this.objectTypeInstance.groups[property.group];

							if ('operators' in group) {
								return group.operators;
							}
						}
					}

					return [
						'is',
						'isnot',
						'>',
						'>=',
						'<',
						'<=',
						'contains',
						'starts_with',
						'ends_with',
						'like',
					];

				}
			},
		});

	};

	this.initResultsPreviewComponent = function () {

		var updateResults = function () {
			var vm = this;

			if (this.missingTemplates.length || this.hasFilterFieldValue) {
				return;
			}

			this.loading = true;

			this.getPreviewResults().done(function (results) {
				vm.loading = false;
				vm.results = results;
			}).fail(function () {
				vm.results = null;
				vm.loading = false;
			});
		};

		Vue.component('gppa-results-preview', {
			template: '#gppa-results-preview',
			data: function () {
				return {
					loading: false,
					previewResultsPromise: null,
					results: null,
				};
			},
			created: function () {
				this.updateResults();
			},
			props: [
				'populate',
				'enabled',
				'field',
				'objectTypeInstance',
				'filterGroups',
				'templates',
				'templateRows',
				'orderingMethod',
				'orderingProperty',
				'uniqueResults',
			],
			watch: {
				filterGroups: {
					handler: function () {
						this.updateResultsDebounced();
					},
					deep: true,
				},
				templates: {
					handler: function () {
						this.updateResultsDebounced();
					},
					deep: true,
				},
				orderingProperty: function () {
					this.updateResults();
				},
				orderingMethod: function () {
					this.updateResults();
				},
				uniqueResults: function () {
					this.updateResults();
				},
				objectTypeInstance: function () {
					this.results = null;
				},
			},
			computed: {
				resultColumns: function () {
					if (!this.results || !this.results.length) {
						return [];
					}

					return Object.keys(this.results[0]);
				},
				hasFilterFieldValue: function () {

					var hasFilterFieldValue = false;

					this.filterGroups.forEach(function (filterGroup) {
						filterGroup.forEach(function (filter) {
							if (typeof filter.value === 'string' && filter.value.indexOf('gf_field') === 0) {
								hasFilterFieldValue = true;
							}
						});
					});

					return hasFilterFieldValue;

				},
				missingTemplates: function () {
					var vm = this;
					var missingTemplates = [];

					this.templateRows.forEach(function (templateRow) {
						if (!(templateRow.id in vm.templates) || !vm.templates[templateRow.id]) {
							missingTemplates.push(templateRow.label);
						}
					});

					return missingTemplates;
				},
			},
			methods: {
				updateResults: updateResults,
				updateResultsDebounced: gppaDebounce(updateResults, 500),
				getPreviewResults: function () {
					if (this.previewResultsPromise && this.previewResultsPromise.state() !== 'resolved') {
						this.previewResultsPromise.abort();
					}

					this.previewResultsPromise = $.post(ajaxurl, {
						action: 'gppa_get_query_results',
						templateRows: this.templateRows,
						gppaPopulate: this.populate,
						fieldSettings: JSON.stringify(window.field)
					}, null, 'json');

					return this.previewResultsPromise;
				},
			}
		});

	};

	this.initGPPAPopulateDynamicallyComponent = function () {

		Vue.component('gppa-populate-dynamically', {
			template: '#gppa-populate-dynamically',
			data: function () {
				return this.defaultData();
			},
			created: function () {
				var vm = this;

				$.each(this.fieldSettingMap, function(property, fieldSetting) {
					vm.$watch(property, function (val, oldVal) {
						try {
							if (typeof val !== 'undefined') {
								SetFieldProperty(fieldSetting, JSON.parse(JSON.stringify(val)));
							}
						} catch (e) {
							console.warn(e);
						}
					}, { deep: true });
				});
			},
			props: [
				'field',
				'populate',
			],
			watch: {
				field: {
					handler: function (field, prevField) {
						/* Disable GPPA if 'enableCalculation' is enabled on the current field */
						if ('enableCalculation' in field && field.enableCalculation) {
							this.enabled = false;
						}

						if (prevField && field.id === prevField.id) {
							return;
						}

						this.initialLoad();
					},
					deep: true,
				},
				objectType: function () {
					if (!this.objectTypeInstance) {
						return;
					}

					if ('primary-property' in this.objectTypeInstance && !this.usingFieldObjectType) {
						this.getPropertyValues('primary-property');
					} else {
						this.getProperties();
					}
				},
				primaryProperty: function () {
					if (!this.objectTypeInstance) {
						return;
					}

					if (this.usingFieldObjectType && !('primary-property' in this.objectTypeInstance)) {
						return;
					}

					this.getProperties();
				},
				enabled: function ( val ) {

					this.toggleStaticChoices();

					if (this.populate === 'choices') {
						var choices = [];
						var field = GetSelectedField();

						if (field.choices && field.choices.length) {
							if (field.placeholder) {
								choices.push(new Choice(field.placeholder));
							}

							choices.push(new Choice('First Choice'), new Choice('Second Choice'), new Choice('Third Choice'));

							if (val) {
								choices.push(new Choice('Fourth Choice'), new Choice('Fifth Choice'));
							}

							SetFieldProperty('choices', choices);
							UpdateFieldChoices(GetInputType(GetSelectedField()));
							LoadFieldChoices(GetSelectedField())
						}
					}

					this.toggleEnabledClass();

				},
			},
			computed: {
				fieldSettingMap: function () {
					var prefix = 'gppa-' + this.populate + '-';

					return {
						'enabled': prefix + 'enabled',
						'objectType': prefix + 'object-type',
						'primaryProperty': prefix + 'primary-property',
						'orderingProperty': prefix + 'ordering-property',
						'orderingMethod': prefix + 'ordering-method',
						'filterGroups': prefix + 'filter-groups',
						'templates': prefix + 'templates',
						'uniqueResults': prefix + 'unique-results',
					};
				},
				fieldSettingConversion: function () {
					var prefix = 'gppa-' + this.populate + '-';

					return {
						'templates': function () {
							if (window.field && prefix + 'templates' in window.field) {
								var value = window.field[prefix + 'templates'];

								if (typeof value !== 'undefined' && Array.isArray(value)) {
									return {};
								}

								return value;
							}

							return undefined;
						}
					};
				},
				objectTypeInstance: function () {
					if (!this.objectType) {
						return null;
					}

					if (this.usingFieldObjectType) {
						var targetFieldSettings = this.fieldObjectTypeTargetFieldSettings;

						if (!targetFieldSettings || !targetFieldSettings['gppa-choices-object-type'] || !window.GPPA_ADMIN.objectTypes[targetFieldSettings['gppa-choices-object-type']]) {
							this.objectType = '';

							return;
						}

						var fieldObjectType = window.GPPA_ADMIN.objectTypes[targetFieldSettings['gppa-choices-object-type']];

						return Object.assign({}, fieldObjectType);
					}

					return Object.assign({}, window.GPPA_ADMIN.objectTypes[this.objectType]);
				},
				primaryPropertyComputed: function () {
					if (this.usingFieldObjectType) {
						return this.fieldObjectTypeTargetFieldSettings['gppa-choices-primary-property'];
					}

					return this.primaryProperty;
				},
				usingFieldObjectType: function () {
					return this.objectType.indexOf('field_value_object') === 0;
				},
				fieldObjectTypeTargetFieldSettings: function () {
					if (!this.usingFieldObjectType) {
						return null;
					}

					var targetFieldID = this.objectType.split(':')[1];

					return window.form.fields.filter(function (field) {
						return field.id == targetFieldID;
					})[0];
				},
				fieldValueObjects: function () {

					var vm = this;

					return window.form.fields.filter(function (field) {
						if (!('choices' in field)) {
							return;
						}

						if (field.id === vm.field.id) {
							return;
						}

						return 'gppa-choices-enabled' in field && field['gppa-choices-enabled'] && field['gppa-choices-object-type'];
					});

				},
				groupedProperties: function () {
					var groupedProperties = Object.assign({}, this.properties);
					delete groupedProperties.ungrouped;

					return groupedProperties;
				},
				ungroupedProperties: function () {
					return this.properties.ungrouped;
				},
				orderingProperties: function () {
					return Object.values(this.flattenedProperties).filter(function (prop) {
						return 'orderby' in prop && prop.orderby;
					});
				},
				flattenedProperties: function () {
					var propertiesFlat = {};
					var vm = this;

					Object.keys(this.properties).forEach(function (group) {
						var groupProperties = vm.properties[group];

						groupProperties.forEach(function (property) {
							propertiesFlat[property.value] = property;
						});
					});

					return propertiesFlat;
				},
				currentFieldSettings: function () {
					return $.map(window.fieldSettings[this.field.type].split(','), function (value) {
						return value.trim();
					});
				},
				isSupportedField: function () {
					if (!this.field) {
						return false;
					}

					/* Exclude field if calculation is enabled */
					if ('enableCalculation' in this.field && this.field.enableCalculation) {
						return false;
					}

					/* Exclude specific field types */
					if (['consent', 'tos', 'list'].indexOf(this.field.type) !== -1) {
						return false;
					}

					switch (this.populate) {
						case 'choices':
							if ('choices' in this.field && this.field.choices !== '') {
								/* Exclude chained selects */
								if (this.field.choices[0] && 'choices' in this.field.choices[0]) {
									return false;
								}

								return true;
							}
							break;

						case 'values':
							if ('choices' in this.field && this.field.choices !== '') {
								/* Exclude chained selects */
								if (this.field.choices[0] && 'choices' in this.field.choices[0]) {
									return false;
								}

								return true;
							}

							/* Single input */
							if (this.currentFieldSettings.indexOf('.default_value_setting') !== -1) {
								return true;
							}

							/* Textarea */
							if (this.currentFieldSettings.indexOf('.default_value_textarea_setting') !== -1) {
								return true;
							}

							/* Input with multiple fields */
							if (this.currentFieldSettings.indexOf('.default_input_values_setting') !== -1) {
								return true;
							}

							break;
					}

					return false;
				},
				templateRows: function () {
					var templateRows = [];

					if (!this.field) {
						return templateRows;
					}

					switch (this.populate) {
						case 'choices':
							templateRows.push({id: 'value', label: this.i18nStrings.value});
							templateRows.push({id: 'label', label: this.i18nStrings.label});

							if (this.field['type'] === 'product') {
								templateRows.push({id: 'price', label: this.i18nStrings.price});
							}
							break;

						case 'values':
							if (this.field.inputs) {
								$.each(this.field.inputs, function (index, input) {
									if (input.isHidden) {
										return;
									}

									templateRows.push({id: input.id, label: input.label});
								});
							} else {
								templateRows.push({id: 'value', label: this.i18nStrings.value});
							}
							break;
					}

					return templateRows;
				},
			},
			methods: {
				defaultData: function () {
					return {
						enabled: false,
						uniqueResults: true,
						objectType: '',
						primaryProperty: '',
						properties: [],
						propertyValues: {},
						orderingProperty: '',
						orderingMethod: 'asc',
						filterGroups: [],
						i18nStrings: window.GPPA_ADMIN.strings,
						templates: {},
					};
				},
				initialLoad: function () {
					var vm = this;

					Object.assign(vm.$data, this.defaultData());

					$.each(this.fieldSettingMap, function(property, fieldSetting) {
						if (typeof vm.fieldSettingConversion[property] === 'function') {
							var value = vm.fieldSettingConversion[property]();

							if (typeof value !== 'undefined') {
								vm.$data[property] = value;
							}

							return;
						}

						if (fieldSetting in window.field) {
							vm.$data[property] = window.field[fieldSetting];
						}
					});

					if (!this.objectTypeInstance || !this.isSupportedField) {
						this.showStaticSettings();

						return;
					}

					this.hideStaticSettings();

					if ('primary-property' in this.objectTypeInstance && !this.usingFieldObjectType) {
						this.getPropertyValues('primary-property');

						if (!this.primaryProperty) {
							return;
						}
					}

					this.getProperties();

					$.each(this.filterGroups, function(index, filters) {
						$.each(filters, function(index, filter) {
							vm.getPropertyValues(filter.property);
						});
					});
				},
				showStaticSettings: function () {
					if (!this.isSupportedField) {
						return;
					}

					switch (this.populate) {
						case 'choices':
							window.field.choices && $('.choices_setting').show();
							break;
					}
				},
				hideStaticSettings: function () {
					if (!this.isSupportedField) {
						return;
					}

					switch (this.populate) {
						case 'choices':
							window.field.choices && $('.choices_setting').hide();
							break;
					}
				},
				toggleStaticChoices: function () {
					if (this.enabled === true) {
						this.hideStaticSettings();
					} else if (this.enabled === false) {
						this.showStaticSettings();
					}
				},
				toggleEnabledClass: function() {
					if (this.enabled === true) {
						$( this.$el ).parents( '.gfield' ).addClass( 'gppa-' + this.populate + '-enabled' );
					} else if (this.enabled === false) {
						$( this.$el ).parents( '.gfield' ).removeClass( 'gppa-' + this.populate + '-enabled' );
					}
				},
				changeObjectType: function () {
					this.propertyValues = this.defaultData().propertyValues;
					this.primaryProperty = this.defaultData().primaryProperty;
					this.filterGroups = this.defaultData().filterGroups;
					this.properties = this.defaultData().properties;
					this.orderingProperty = this.defaultData().orderingProperty;
					this.orderingMethod = this.defaultData().orderingMethod;

					if (typeof this.objectTypeInstance.templates === 'object' && Object.keys(this.objectTypeInstance.templates).length) {
						this.templates = Object.assign({}, this.objectTypeInstance.templates);
					} else {
						this.templates = this.defaultData().templates;
					}
				},
				changePrimaryProperty: function () {
					this.filterGroups = this.defaultData().filterGroups;
				},
				filterFactory: function () {
					var date = new Date();

					return {
						property: '',
						operator: '',
						value: '',
						uuid: date.getTime(),
					};
				},
				addFilterGroup: function () {
					this.filterGroups.push([this.filterFactory()])
				},
				addFilter: function (filterIndex, filterGroupIndex) {
					if (!isNaN(filterIndex)) {
						this.filterGroups[filterGroupIndex].splice(filterIndex + 1, 0, this.filterFactory());

						return;
					}

					this.filterGroups[filterGroupIndex].push(this.filterFactory());
				},
				removeFilter: function (index, filterGroupIndex) {
					this.filterGroups[filterGroupIndex].splice(index, 1);

					if (this.filterGroups[filterGroupIndex].length === 0) {
						this.filterGroups.splice(filterGroupIndex, 1);
					}
				},
				resetPropertyValues: function (keepPrimaryPropertyValues) {
					var primaryPropertyValues = Object.assign({}, this.propertyValues['primary-property'] || {});
					this.propertyValues = this.defaultData().propertyValues;

					if (keepPrimaryPropertyValues && Object.keys(primaryPropertyValues).length) {
						this.propertyValues['primary-property'] = primaryPropertyValues;
					}
				},
				getProperties: function () {
					this.resetPropertyValues(true);

					var ajaxArgs = {
						'action': 'gppa_get_object_type_properties',
						'object-type': this.objectTypeInstance.id
					};

					if ('primary-property' in this.objectTypeInstance && this.primaryPropertyComputed) {
						ajaxArgs['primary-property-value'] = this.primaryPropertyComputed;
					}

					var vm = this;

					$.post(ajaxurl, ajaxArgs, null, 'json').done(function (data) {
						vm.properties = Object.assign({}, data);
					});
				},
				getPropertyValues: function (property) {
					var vm = this;

					if (property instanceof Event) {
						property = property.target.value;
					}

					if (property in vm.propertyValues) {
						return vm.propertyValues[property];
					}

					var ajaxArgs = {
						'action': 'gppa_get_property_values',
						'object-type': this.objectTypeInstance.id,
						'property': property
					};

					if ('primary-property' in this.objectTypeInstance && this.primaryPropertyComputed && property !== 'primary-property') {
						ajaxArgs['primary-property-value'] = this.primaryPropertyComputed;
					}

					$.post(ajaxurl, ajaxArgs, null, 'json').done(function (data) {
						/* See https://vuejs.org/v2/guide/list.html#Object-Change-Detection-Caveats */
						vm.$set(vm.propertyValues, property, $.map(data, function (option, index) {
							var value = option;
							var label = option;

							if (Array.isArray(option)) {
								value = option[0];
								label = option[1];
							}

							return {
								value: value,
								label: label
							}
						}));
					});
				},
				truncateStringMiddle: gppaTruncateStringMiddle,
			}
		});

	};

	this.initVueVM = function () {

		this.vm = new Vue({
			el: '#gppa',
			data: {
				field: null,
			},
			methods: {
				initialLoad: function () {
					this.$refs.choices.initialLoad();
					this.$refs.values.initialLoad();
				},
			}
		});

	};

	this.init();

}

/**
 * @credit https://davidwalsh.name/function-debounce
 */
function gppaDebounce (func, wait, immediate) {
	var timeout;
	return function () {
		var context = this, args = arguments;
		var later = function () {
			timeout = null;
			if (!immediate) func.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow) func.apply(context, args);
	};
}

function gppaTruncateStringMiddle (str) {
	var maxLength = 50;

	if (!str || typeof str !== 'string') {
		return str;
	}

	if (str.length > maxLength) {
		return str.substr(0, maxLength * .45) + ' ... ' + str.substr(str.length - (maxLength * .4), str.length);
	}

	return str;
}
