(function ($) {

	window.GPPAGetFormFieldValues = function (formId) {

		var $form = $('#gform_' + formId);

		/* Use entry form if we're in the Gravity Forms admin entry view. */
		if ( $('#wpwrap #entry_form').length ) {
			$form = $('#entry_form');
		}

		var inputsArray = $.grep($form.serializeArray(), function (value) {
			if (value.name.indexOf('input_') !== 0) {
				return false;
			}

			return true;
		});

		var inputsObject = {};

		$.each(inputsArray, function (index, input) {
			inputsObject[input.name.replace('input_', '')] = input.value;
		});

		return inputsObject;

	};

	window.GPPAGetFieldFilterValues = function (formId, filters) {

		var $form = $('#gform_' + formId);

		/* Use entry form if we're in the Gravity Forms admin entry view. */
		if ( $('#wpwrap #entry_form').length ) {
			$form = $('#entry_form');
		}

		var formInputValues = $form.serializeArray();
		var gfFieldFilters = [];
		var values = {};

		$.each(filters, function (index, filter) {
			gfFieldFilters.push('input_' + filter.gf_field);
		});

		formInputValues.forEach(function (input) {
			if ( gfFieldFilters.indexOf(input.name) === -1 ) {
				return;
			}

			values[input.name.replace('input_', '')] = input.value;
		});

		return values;

	};

	/**
	 * This is primarily used for field value objects since it has to traverse up
	 * and figure out what other filters are required.
	 *
	 * Regular filters work without this since all of the filters are present in the single field.
	 **/
	var recursiveGetDependentFilters = function (filters, formId) {

		var dependentFilters = [];

		$.each(filters, function(index, filter) {
			if ('property' in filter || !('gf_field' in filter)) {
				return;
			}

			var currentField = filter.gf_field;

			if (!(currentField in gppaMergedFieldMaps[formId])) {
				return;
			}

			dependentFilters = dependentFilters
				.concat(gppaMergedFieldMaps[formId][currentField])
				.concat(recursiveGetDependentFilters(gppaMergedFieldMaps[formId][currentField], formId));
		});

		return dependentFilters;

	};

	var getBatchFieldHTML = function (requestedFields, formId) {

		var filters = [];
		var fieldIDs = [];
		var fields = [];

		/* Process field array and populate filters */
		$.each(requestedFields, function(index, fieldDetails) {
			var fieldID = fieldDetails.field;

			if (fieldIDs.indexOf(fieldID) !== -1) {
				return;
			}

			fields.push(Object.assign({}, fieldDetails, {
				$el: $('#field_' + formId + '_' + fieldID),
			}));

			filters = filters
				.concat(fieldDetails.filters)
				.concat(recursiveGetDependentFilters(fieldDetails.filters, formId));

			fieldIDs.push(fieldID);
		});

		fields.sort(function(a, b) {
			var aIndex = a.$el.index('[id^=field]');
			var bIndex = b.$el.index('[id^=field]');

			return aIndex - bIndex;
		});

		var fieldValues = GPPAGetFieldFilterValues(formId, filters);

		$.each(fields, function(index, fieldDetails) {

			var fieldID = fieldDetails.field;
			var $el = fieldDetails.$el;
			var $fieldGinputContainer = $el.find('.ginput_container');
			var spinnerSource = GPPA_GF_BASEURL + '/images/spinner.gif';

			/* Prevent multiple choices hidden inputs */
			$el
				.closest('form')
				.find('input[type="hidden"][name="input_' + fieldID + '_choices"]')
				.remove();

			$fieldGinputContainer.html('<div class="gppa-loading"><img class="gfspinner"  src="' + spinnerSource + '" /> Loading...</div>');

		});

		return $.post(GPPA_AJAXURL, {
			'action': 'gppa_get_batch_field_html',
			'form-id': formId,
			'lead-id': null,
			'field-ids': fields.map(function (field) { return field.field; }),
			'field-values': fieldValues,
			'security': window.GPPA_NONCE,
		}, function (fieldHTMLResults) {

			$.each(fields, function(index, fieldDetails) {
				var fieldID = fieldDetails.field;
				var $field = fieldDetails.$el;

				$field.find('.ginput_container').replaceWith(fieldHTMLResults[fieldID]);

				gform.doAction('gform_input_change', $field.find('.ginput_container'), formId, fieldID);
			});

			runAndBindCalculationEvents( fields, formId );

			$(document).trigger('gppa_updated_batch_fields');

		}, 'json');

	};

	/**
	 * Run the calculation events for any field that is dependent on a GPPA-populated field that has been updated.
	 *
	 * @param fields
	 * @param formId
	 */
	var runAndBindCalculationEvents = function( fields, formId ) {

		if( ! window.gf_global || ! window.gf_global.gfcalc || ! window.gf_global.gfcalc[ formId ] ) {
			return;
		}

		var GFCalc = window.gf_global.gfcalc[ formId ];

		for( var i = 0; i < GFCalc.formulaFields.length; i++ ) {
			var formulaField = $.extend( {}, GFCalc.formulaFields[i] );
			GFCalc.runCalc( formulaField, formId );
		}

	};

	window.GPPAGetDependentFields = function (fieldId, formId, map) {

		if (!map) {
			throw new Error('Field filter map not valid');
		}

		if (!(formId in map)) {
			debugger;
			return [];
		}

		var dependentFields = [];
		var currentFieldDependents;
		var currentFields = [fieldId.toString()];

		while (currentFields) {

			currentFieldDependents = [];

			$.each(map[formId], function (field, filters) {
				$.each(filters, function (index, filter) {
					if ('gf_field' in filter && $.inArray(filter.gf_field.toString(), currentFields) !== -1) {
						currentFieldDependents.push(field);
						dependentFields.push({ field: field, filters: filters });
					}
				});
			});

			if (!currentFieldDependents.length) {
				break;
			}

			currentFields = currentFieldDependents;

		}

		return dependentFields;

	};

	var initialFieldsToLoad = {};
	var gppaMergedFieldMaps = {};

	if ('GPPA_FILTER_FIELD_MAP' in window && window.GPPA_FILTER_FIELD_MAP) {
		$.extend(true, gppaMergedFieldMaps, window.GPPA_FILTER_FIELD_MAP);
	}

	if ('GPPA_FIELD_VALUE_OBJECT_MAP' in window && window.GPPA_FIELD_VALUE_OBJECT_MAP) {
		$.extend(true, gppaMergedFieldMaps, window.GPPA_FIELD_VALUE_OBJECT_MAP);
	}

	$(document).on('gform_post_render', function () {

		$.each(gppaMergedFieldMaps, function (formId, fields) {
			GPPAUpdateDepedentFields = function () {
				var fieldId = $(this).attr('name').replace(/^input_/, '');
				var dependentFieldIds = GPPAGetDependentFields(fieldId, formId, gppaMergedFieldMaps);

				getBatchFieldHTML(dependentFieldIds, formId);
			};

			/* Bind to change */
			var $form = $('#gform_' + formId);

			/* Use entry form if we're in the Gravity Forms admin entry view. */
			if ( $('#wpwrap #entry_form').length ) {
				$form = $('#entry_form');
			}

			$form.on('change', '[name^="input_"]', window.GPPAUpdateDepedentFields);

			$.each(fields, function (gppaField, filters) {
				if (!(formId in initialFieldsToLoad)) {
					initialFieldsToLoad[formId] = [];
				}

				initialFieldsToLoad[formId].push({ field: gppaField, filters: filters });
			});
		});

		$.each(initialFieldsToLoad, function(formId, fields) {
			getBatchFieldHTML(fields, formId);
		});

	});

	window.GPPALiveMergeTags = function () {

		var self = this;

		this.$registeredEls = $();
		this.formId = null;
		this.mergeTagValuesPromise = null;

		this.init = function () {
			self.getRegisteredEls();
			self.bind();
		};

		this.onPageChange = gppaDebounce(function () {
			self.getRegisteredEls();
			self.getFormId();

			self.getMergeTagValues(true)
				.then(self.replaceMergeTagValues);
		}, 250);

		this.bind = function () {
			/* TODO: make sure this works with batch updates, page changes, and input changes that aren't in batch updates */
			/* TODO: Do not update merge tags that don't have an updated field */
			$(document).on('change keyup', '.gform_fields input, .gform_fields select, .gform_fields textarea', function (event) {
				if ($(this).closest('.gfield_trigger_change').length) {
					return;
				}

				gf_raw_input_change(event, this);
			});

			$(document).on('gform_post_render', self.onPageChange);
			$(document).on('gppa_updated_batch_fields', self.onPageChange);

			gform.addAction('gform_input_change', self.onInputChange, 10);
		};

		this.onInputChange = gppaDebounce(function (elem, formId, fieldId) {
			self.showLoadingIndicators();

			return self.getMergeTagValues(true)
				.then(self.replaceMergeTagValues);
		}, 250);

		this.getFormId = function () {
			this.formId = $('form[id^="gform_"]').prop('id').replace('gform_', '');

			return this.formId;
		};

		this.getRegisteredEls = function () {
			self.$registeredEls = $('[data-gppa-live-merge-tag]');
		};

		this.getRegisteredMergeTags = function () {
			var mergeTags = [];

			self.$registeredEls.each(function () {
				mergeTags.push($(this).data('gppa-live-merge-tag'));
			});

			return mergeTags;
		};

		this.getMergeTagValues = function (skipCache) {

			if (self.mergeTagValuesPromise && !skipCache) {
				return self.mergeTagValuesPromise;
			}

			self.mergeTagValuesPromise = $.post(GPPA_AJAXURL, {
				'action': 'gppa_get_live_merge_tag_values',
				'form-id': self.formId,
				'field-values': GPPAGetFormFieldValues(self.formId),
				'merge-tags': self.getRegisteredMergeTags(self.formId),
				'security': window.GPPA_NONCE
			}, null, 'json');

			return self.mergeTagValuesPromise;

		};

		this.showLoadingIndicators = function () {
			self.$registeredEls.each(function () {
				$(this).html(window.GPPA_I18N.loadingEllipsis);
			});
		};

		this.replaceMergeTagValues = function (mergeTagValues) {
			self.$registeredEls.each(function () {
				var elementMergeTag = $(this).data('gppa-live-merge-tag');

				if (!(elementMergeTag in mergeTagValues)) {
					return;
				}

				$(this).html(mergeTagValues[elementMergeTag]);
			});

			return $.when();
		};

		this.init();

	};

	/**
	* @credit https://davidwalsh.name/function-debounce
	*/
	function gppaDebounce (func, wait, immediate) {
		var timeout;
		return function () {
			var context = this, args = arguments;
			var later = function () {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			var callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	}

	window.gppaLiveMergeTags = new window.GPPALiveMergeTags();

})(jQuery);
