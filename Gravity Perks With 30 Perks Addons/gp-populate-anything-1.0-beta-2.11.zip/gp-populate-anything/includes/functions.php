<?php
function gppa_is_assoc_array( Array $array ) {
	return ( array_values( $array ) !== $array );
}
