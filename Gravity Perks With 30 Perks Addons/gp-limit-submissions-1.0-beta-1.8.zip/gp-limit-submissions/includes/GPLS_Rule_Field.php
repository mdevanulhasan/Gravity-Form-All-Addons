<?php

class GPLS_Rule_Field extends GPLS_Rule {
	private $field;

	public static function load( $ruleData ) {
		$rule        = new self;
		$rule->field = $ruleData['rule_field'];

		return $rule;
	}

	public function context() {
		// field rule is always in context, query will check if there is a submission
		// if there is not a submission, we still want to check the ruleset because it may still be applicable
		return true;
	}

	public function query() {

		global $wpdb;
		// load form and field
		$form  = GFAPI::get_form( $this->form_id );
		$field = GFFormsModel::get_field( $form, $this->get_field() );
		// subfield inputs
		if ( ! empty( $field['inputs'] ) ) {

			// loop over subfields, getting value if not hidden
			$joins  = array();
			$wheres = array();
			foreach ( $field['inputs'] as $subfield ) {

				// check if this is the input we're currently processing
				if ( intval( $subfield['id'] ) != $this->get_field() ) {
					continue;
				}
				// input hidden
				if ( ! empty( $subfield['isHidden'] ) ) {
					continue;
				}
				$table_slug = sprintf( 'em%s', str_replace( '.', '_', $subfield['id'] ) );
				$value      = $this->get_limit_field_value( $subfield['id'] );
				// input has no value
				if ( empty( $value ) ) {
					continue;
				}
				// add join/where to array
				$joins[]  = "INNER JOIN {$wpdb->prefix}gf_entry_meta {$table_slug} ON {$table_slug}.entry_id = e.id";
				$wheres[] = $wpdb->prepare( "\n( {$table_slug}.meta_key = %s AND {$table_slug}.meta_value = %s )", $subfield['id'], $value );
			}

			if ( ! empty( $joins ) ) {
				return array(
					'join'  => $joins,
					'where' => $wheres,
				);
			} else {
				return array();
			}
			// singular field
		} else {

			$value      = $this->get_limit_field_value( $this->get_field() );
			$table_slug = sprintf( 'em%s', str_replace( '.', '_', $this->get_field() ) );

			return array(
				'join'  => "INNER JOIN {$wpdb->prefix}gf_entry_meta {$table_slug} ON {$table_slug}.entry_id = e.id",
				'where' => $wpdb->prepare( "\n( {$table_slug}.meta_key = %s AND {$table_slug}.meta_value = %s )", $this->get_field(), $value )
			);
		}
	}

	public function get_limit_field_value( $field_id ) {

		$form  = GFAPI::get_form( $this->form_id );
		$field = GFFormsModel::get_field( $form, $field_id );
		if ( ! $field ) {
			return false;
		}
		$input_name = 'input_' . str_replace( '.', '_', $field_id );

		return GFFormsModel::prepare_value( $form, $field, rgpost( $input_name ), $input_name, null );
	}

	public function render_option_fields( $gfaddon ) {
		$gfaddon->settings_select(
			array(
				'label'   => __( 'User ID', 'gp-limit-submissions' ),
				'name'    => 'rule_field_{i}',
				'class'   => 'rule_value_selector rule_field rule_field_{i} gpls-secondary-field',
				'choices' => $this->get_field_list(),
			)
		);
	}

	public function get_field() {
		return $this->field;
	}

	public function get_field_list() {
		$choices = array();
		$form    = GFAPI::get_form( $this->get_form_id() );
		foreach ( $form['fields'] as $field ) {

			// main field
			$choice    = array(
				'label' => $field['label'],
				'value' => $field['id'],
			);
			$choices[] = $choice;
			// add subfields
			if ( ! empty( $field['inputs'] ) ) {

				foreach ( $field['inputs'] as $subfield ) {

					if ( ! empty( $subfield['isHidden'] ) ) {
						continue;
					}
					$choice    = array(
						'label' => $field['label'] . ' (' . $subfield['label'] . ')',
						'value' => $subfield['id'],
					);
					$choices[] = $choice;
				}
			}
		}

		return $choices;
	}

	public function get_form_id() {
		if ( $_GET && isset( $_GET['id'] ) ) {
			return $_GET['id'];
		}

		return 0;
	}

	public function get_type() {
		return 'field';
	}
}
